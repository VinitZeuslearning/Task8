// import inputTxtSharedObj from "../utils/inputTxtSharedOb.js";

export default class InputTxt {

    constructor() {
        this.canvaRowInd = 0;
        this.canvaColInd = 0;
        this.cellRow = 0;
        this.cellCol = 0;
        this.masterHobj = null;
        this.masterWobj = null;
        this.posX = 0;
        this.posY = 0;
        this.colsPerCanva = 0;
        this.rowsPerCanva = 0;
        this._inpElm = document.getElementById("inputTxt");
        // this._inpElm.id = "inputTxt";
        this.inptVal = "";
    }

    render() {
        this._inpElm.style.top = this.posY + "px";
        this._inpElm.style.left = this.posX + "px";
        this._inpElm.style.height = this.masterHobj.getValue(this.cellRow) - 2 + "px";
        this._inpElm.style.width = this.masterWobj.getValue(this.cellCol) - 2 + "px";
        this._inpElm.value = this.inptVal;
    }
    reRender() {
        // Calculate starting Y position for this canvas
        let posY = this.masterHobj.cnvdM.getPrefVal(this.canvaRowInd);
        // Calculate starting X position for this canvas
        let posX = this.masterWobj.cnvdM.getPrefVal(this.canvaColInd);

        // Add up cell heights from canvas start to current cellRow
        for (let i = this.canvaRowInd * this.rowsPerCanva; i < this.cellRow; i++) {
            posY += this.masterHobj.getValue(i);
        }

        // Add up cell widths from canvas start to current cellCol
        for (let j = this.canvaColInd * this.colsPerCanva; j < this.cellCol; j++) {
            posX += this.masterWobj.getValue(j);
        }

        // Set calculated positions to instance variables
        this.posX = posX;
        this.posY = posY;

        // Update input box position and size
        this._inpElm.style.top = this.posY + "px";
        this._inpElm.style.left = this.posX + "px";
        this._inpElm.style.height = (this.masterHobj.getValue(this.cellRow) - 2) + "px";
        this._inpElm.style.width = (this.masterWobj.getValue(this.cellCol) - 2) + "px";

        // Update input value if needed
        this._inpElm.value = this.inptVal;
    }

}