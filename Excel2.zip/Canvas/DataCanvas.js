import adjustCanvasDPI from "../utils/adjustDpi.js";
export default class Canva {
    constructor() {
        this._dataStg = null;
        this.celldt = null;
        this._parent = document.getElementById('canvaManager');
        this._canva = document.createElement('canvas');
        this.ctx = this._canva.getContext('2d');
        this.currRow = -1;
        this.currCol = -1;
        this.fontSize = 10;
        this.rowsHeight;
        this.colswidth;
        this.canvaHeight = 0;
        this.canvaWidth = 0;
        this.cellHeight = 0;
        this.cellWidth = 0;
        this.rowNumber = 0;
        this.colNumber = 0;
        this.masterHobj = null;
        this.masterWobj = null;
        this.canvaRowIndex = null;
        this.canvaColIndex = null;
        this.inputElmObj = null;

        this.rowIndexStartFrm = this.canvaRowIndex * this.rowNumber;
        this.colIndexStartFrm = this.canvaColIndex * this.colNumber;
    }

    adjustCanvasDPI() {
        const dpr = window.devicePixelRatio;
        const cssWidth = this._canva.clientWidth;
        const cssHeight = this._canva.clientHeight;

        // Set the internal pixel size of the canvas
        this._canva.width = Math.floor(cssWidth * dpr);
        this._canva.height = Math.floor(cssHeight * dpr);

        // Set the CSS size so it stays visually the same size on screen
        this._canva.style.width = `${cssWidth}px`;
        this._canva.style.height = `${cssHeight}px`;

        // this.ctx.setTransform(1, 0, 0, 1, 0, 0);
        this.ctx.scale(dpr, dpr);
    }

    static performBinarySearch(arr, num) {
        if (num > arr[arr.length - 1] || num < arr[0]) {
            return -1;
        }
        let i = 0;
        let j = arr.length - 1;


        let mid;
        while (i < j) {
            mid = Math.ceil(i + ((j - i) / 2));

            if (arr[mid] > num) {
                j = mid - 1;
            }
            else {
                i = mid;
            }
        }
        return i;
    }
    render() {
        // Reset transform
        // this.ctx.setTransform(1, 0, 0, 1, 0, 0);

        // Clear canvas
        this.ctx.clearRect(0, 0, this._canva.width, this._canva.height);

        // Update canvas size
        this.canvaHeight = this.masterHobj.cnvdM.getValue(this.canvaRowIndex);
        this.canvaWidth = this.masterWobj.cnvdM.getValue(this.canvaColIndex);
        this._canva.style.height = this.canvaHeight + "px";
        this._canva.style.width = this.canvaWidth + "px";

        // Adjust for device pixel ratio
        this.adjustCanvasDPI();

        let height = this.canvaHeight;
        let width = this.canvaWidth;

        this.ctx.lineWidth = 1;

        // Pixel-perfect align strokes
        // this.ctx.translate(0.5, 0.5);

        // Draw horizontal grid lines
        let y = 0;
        let ind;
        this.ctx.font = `${this.fontSize}px 'Courier New', monospace`;
        let Pos = this.rowNumber * this.canvaRowIndex;
        this.ctx.strokeStyle = "#ccc";
        for (ind = 0; ind < this.rowNumber; ind++) {
            y = Math.round(y);  // Snap to integer

            this.ctx.beginPath();
            this.ctx.moveTo(0, y + 0.5);
            this.ctx.lineTo(width, y + 0.5);
            this.ctx.stroke();

            y += this.masterHobj.getValue(Pos);
            Pos++;
        }

        // Draw vertical grid lines
        let x = 0;
        Pos = this.colNumber * this.canvaColIndex;

        for (ind = 0; ind < this.colNumber; ind++) {
            x = Math.round(x);  // Snap to integer

            this.ctx.beginPath();
            this.ctx.moveTo(x + 0.5, 0);
            this.ctx.lineTo(x + 0.5, height);
            this.ctx.stroke();

            x += this.masterWobj.getValue(Pos);
            Pos++;
        }

        // Draw text cells
        let charWidth = this.ctx.measureText("W").width;
        for (let r = 0; r < this.rowNumber; r++) {
            let cellY = r * this.cellHeight + this.cellHeight / 2 + 1;
            let cellX = this.cellWidth / 2;
            for (let c = 0; c < this.colNumber; c++) {
                let tmp = " ";
                tmp = tmp.slice(0, (this.cellWidth / charWidth) - 2);
                this.ctx.fillText(tmp, cellX, cellY);
                cellX += this.cellWidth;
            }
        }

        if (  this.inputElmObj.canvaRowInd == this.canvaRowIndex && this.inputElmObj.canvaColIndex == this.canvaColIndex  ) {
            this.inputElmObj.reRender();
        }
    }

    findCell(x, y) {
        let tmpY = this.rowIndexStartFrm;
        let tmpX = this.colIndexStartFrm;

        // Starting position of this canvas
        let posY = this.masterHobj.cnvdM.getPrefVal(this.canvaRowIndex);
        let posX = this.masterWobj.cnvdM.getPrefVal(this.canvaColIndex);

        let currentY = posY;
        let currentX = posX;

        let cellTop = -1;
        let cellLeft = -1;

        // Find row index and top position
        for (; tmpY < this.rowNumber + this.rowIndexStartFrm; tmpY++) {
            let cellHeight = this.masterHobj.getValue(tmpY);
            if (y >= currentY && y < currentY + cellHeight) {
                cellTop = currentY;
                break;
            }
            currentY += cellHeight;
        }

        // If not found — exit early
        if (tmpY >= this.rowNumber + this.rowIndexStartFrm) return null;

        // Find col index and left position
        for (; tmpX < this.colNumber + this.colIndexStartFrm; tmpX++) {
            let cellWidth = this.masterWobj.getValue(tmpX);
            if (x >= currentX && x < currentX + cellWidth) {
                cellLeft = currentX;
                break;
            }
            currentX += cellWidth;
        }

        // If not found — exit early
        if (tmpX >= this.colNumber + this.colIndexStartFrm) return null;

        // Now both row & col are valid — set into inputElmObj
        this.inputElmObj.posX = cellLeft;
        this.inputElmObj.posY = cellTop;
        this.inputElmObj.canvaColIndex = this.canvaColIndex;
        this.inputElmObj.canvaRowIndex = this.canvaRowIndex;
        this.inputElmObj.cellRow = tmpY;
        this.inputElmObj.cellCol = tmpX;

        this.inputElmObj.render();
    }



    setInputPos(obj) {
        if (!obj) return; // defensive check if click outside grid region
        this.inpElm.style.top = obj.top + "px";
        this.inpElm.style.left = obj.left - 2 + "px";
        this.inpElm.style.height = this.masterHobj.getValue(obj.row) + "px";
        this.inpElm.style.width = this.masterWobj.getValue(obj.col) + "px";
    }


    changeVal(r, c, val) {
        // Value-changing logic here
    }

    _initialize(cellHeight = 20, cellWidth = 100, rowNumber = 0, colNumber = 0) {

        this._canva.addEventListener('click', (e) => {
            const container = document.getElementById("canvaManager");
            const rect = container.getBoundingClientRect();

            const relativeX = e.clientX + container.scrollLeft - rect.left;
            const relativeY = e.clientY + container.scrollTop - rect.top;

            this.findCell(relativeX, relativeY);
        });


        this.cellHeight = cellHeight;
        this.cellWidth = cellWidth;
        this.rowNumber = rowNumber;
        this.colNumber = colNumber;

        this.rowIndexStartFrm = this.canvaRowIndex * this.rowNumber;
        this.colIndexStartFrm = this.canvaColIndex * this.colNumber;

        this.render();
    }
}