

export default inputTxtStateObj = {
    row: 0,
    col: 0,
    top: 0,
    left: 0,
    canvaRowIndex : 0,
    canvaColIndex : 0,
}